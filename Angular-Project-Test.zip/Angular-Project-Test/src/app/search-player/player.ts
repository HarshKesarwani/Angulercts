export class Player{
    _id: string;
    runs : number;
    balls : number;
}