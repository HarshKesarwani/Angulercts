export class Table {
    season: String;
    city: String;
    date: String;
    team1: String;
    team2: String;
    winner: String;
    venue: String;
} 