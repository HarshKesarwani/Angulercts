class Opponent {
    constructor(matches,team1,team2)
    {
        this.matches=matches;
        this.team1=team1;
        this.team2=team2;
    }
}